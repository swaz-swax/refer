package com.cg.atssp.exception;

public class TimeSheetException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public TimeSheetException(String msg) {
		
		super(msg);
	}

}
