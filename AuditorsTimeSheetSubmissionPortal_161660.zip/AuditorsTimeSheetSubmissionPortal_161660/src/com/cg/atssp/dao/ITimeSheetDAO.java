package com.cg.atssp.dao;

import com.cg.atssp.dto.Client;

public interface ITimeSheetDAO {
	
	public Integer timeshetupload(Client timesheet);

}
