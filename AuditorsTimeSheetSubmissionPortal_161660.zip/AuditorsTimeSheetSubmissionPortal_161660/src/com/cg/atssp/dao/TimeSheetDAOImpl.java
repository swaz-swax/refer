package com.cg.atssp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.atssp.dto.Client;


@Repository
@Transactional
public class TimeSheetDAOImpl implements ITimeSheetDAO {

	

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public Integer timeshetupload(Client timesheet) {
		entitymanager.persist(timesheet);
		return timesheet.getTsId();
	}

}
