package com.cg.atssp.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.atssp.dao.ITimeSheetDAO;
import com.cg.atssp.dto.Client;
@Service("service")
@Transactional
public class TimeSheetServiceImpl implements ITimeSheetService {

	@Autowired
	ITimeSheetDAO dao;
	
	@Override
	public Integer TimeSheetUpload(Client ts) {
		
		Integer id=dao.timeshetupload(ts);
		
		return id;
		
		
		
		
	}

}
