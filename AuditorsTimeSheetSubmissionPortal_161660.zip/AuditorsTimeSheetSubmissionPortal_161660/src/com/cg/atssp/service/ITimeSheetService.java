package com.cg.atssp.service;

import com.cg.atssp.dto.Client;

public interface ITimeSheetService  {
	
	public Integer TimeSheetUpload(Client timesheet);
}
