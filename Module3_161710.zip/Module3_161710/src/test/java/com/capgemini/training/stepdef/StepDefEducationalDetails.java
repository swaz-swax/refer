/*
 * Author: Swarup Talukdar
 * Employee ID: 161710
*/
package com.capgemini.training.stepdef;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.training.pageBean.EducationalDetailsPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefEducationalDetails {
	private EducationalDetailsPageFactory educationDetails;
	private WebDriver driver;

	@Given("^user is on the Education Details webpage$")
	public void user_is_on_the_Education_Details_webpage() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Swarup Talukdar\\Workspace\\STS\\selenium\\Module3_161710\\src\\test\\java\\web-driver\\chromedriver.exe");
		driver = new ChromeDriver();
		educationDetails = new EducationalDetailsPageFactory(driver);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get(
				"file:///D:/Swarup Talukdar/Workspace/STS/selenium/Module3_161710/src/test/java/features/EducationalDetails.html");
	}

	@Then("^check the heading of the Education Details page$")
	public void check_the_heading_of_the_Education_Details_page() throws Throwable {
		if (driver.getTitle().contentEquals("Step 2: Educational Details"))
			System.out.println("Title Matched...");
		else {
			System.out.println("Text is not found on page");
			driver.quit();
		}

		driver.close();
	}

	@When("^user forgot select any valid graduation and clicks Register Me button$")
	public void user_forgot_select_any_valid_graduation_and_clicks_Register_Me_button() throws Throwable {
		educationDetails.setGraduation(0);
		Thread.sleep(1000);
		educationDetails.setRegisterMe();
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: " + alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user leaves the percentage field and clicks Register Me button$")
	public void user_leaves_the_percentage_field_and_clicks_Register_Me_button() throws Throwable {
		educationDetails.setGraduation(1);
		Thread.sleep(1000);
		educationDetails.setPercentage("");
		Thread.sleep(1000);
		educationDetails.setRegisterMe();
	}

	@When("^user leaves the passing year field and clicks Register Me button$")
	public void user_leaves_the_passing_year_field_and_clicks_Register_Me_button() throws Throwable {
		educationDetails.setGraduation(1);
		Thread.sleep(1000);
		educationDetails.setPercentage("69");
		Thread.sleep(1000);
		educationDetails.setPassingYear("");
		Thread.sleep(1000);
		educationDetails.setRegisterMe();
	}

	@When("^user leaves the projectName field and clicks Register Me button$")
	public void user_leaves_the_projectName_field_and_clicks_Register_Me_button() throws Throwable {
		educationDetails.setGraduation(1);
		Thread.sleep(1000);
		educationDetails.setPercentage("69");
		Thread.sleep(1000);
		educationDetails.setPassingYear("2014");
		Thread.sleep(1000);
		educationDetails.setProjectName("");
		Thread.sleep(1000);
		educationDetails.setRegisterMe();
	}

	@When("^user forgot to select any Technologies used field and clicks Register Me button$")
	public void user_forgot_to_select_any_Technologies_used_field_and_clicks_Register_Me_button() throws Throwable {
		educationDetails.setGraduation(1);
		Thread.sleep(1000);
		educationDetails.setPercentage("69");
		Thread.sleep(1000);
		educationDetails.setPassingYear("2014");
		Thread.sleep(1000);
		educationDetails.setProjectName("Education");
		Thread.sleep(1000);
		educationDetails.setRegisterMe();
	}

	@When("^user leaves the otherTechnologies field and clicks Register Me button$")
	public void user_leaves_the_otherTechnologies_field_and_clicks_Register_Me_button() throws Throwable {
		educationDetails.setGraduation(1);
		Thread.sleep(1000);
		educationDetails.setPercentage("69");
		Thread.sleep(1000);
		educationDetails.setPassingYear("2014");
		Thread.sleep(1000);
		educationDetails.setProjectName("Education");
		Thread.sleep(1000);
		List<Integer> techList = new ArrayList<Integer>();
		techList.add(1);
		techList.add(2);
		educationDetails.setTechnologiesUsed(techList);
		educationDetails.setOtherTechnologies("");
		educationDetails.setRegisterMe();

	}

	@When("^user enters all datas$")
	public void user_enters_all_datas() throws Throwable {
		educationDetails.setGraduation(1);
		Thread.sleep(1000);
		educationDetails.setPercentage("69");
		Thread.sleep(1000);
		educationDetails.setPassingYear("2014");
		Thread.sleep(1000);
		educationDetails.setProjectName("Education");
		Thread.sleep(1000);
		List<Integer> techList = new ArrayList<Integer>();
		techList.add(1);
		techList.add(2);
		educationDetails.setTechnologiesUsed(techList);
		educationDetails.setOtherTechnologies("Python");
		educationDetails.setRegisterMe();
	}

	@Then("^show alert message for successful registration$")
	public void show_alert_message_for_successful_registration() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: " + alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

}
