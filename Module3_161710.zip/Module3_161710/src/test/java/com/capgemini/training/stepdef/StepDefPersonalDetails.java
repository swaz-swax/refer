/*
 * Author: Swarup Talukdar
 * Employee ID: 161710
*/
package com.capgemini.training.stepdef;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.training.pageBean.PersonalDetailsPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefPersonalDetails {

	private PersonalDetailsPageFactory personalDetails;
	private WebDriver driver;

	@Given("^user is on the Personal Details webpage$")
	public void user_is_on_the_Personal_Details_webpage() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Swarup Talukdar\\Workspace\\STS\\selenium\\Module3_161710\\src\\test\\java\\web-driver\\chromedriver.exe");
		driver = new ChromeDriver();
		personalDetails = new PersonalDetailsPageFactory(driver);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get(
				"file:///D:/Swarup Talukdar/Workspace/STS/selenium/Module3_161710/src/test/java/features/PersonalDetails.html");
	}

	@Then("^check the heading of the Personal Details page$")
	public void check_the_heading_of_the_Personal_Details_page() throws Throwable {
		String strheading = driver.findElement(By.xpath("/html/body/h4")).getText();
		if (strheading.contentEquals("Step 1: Personal Details"))
			System.out.println("Heading Matched...");
		else {
			System.out.println("Text is not found on page.");
			driver.quit();
		}

		Thread.sleep(5000);
		driver.close();
	}

	@When("^user leaves fisrtname field blank and clicks the  next button$")
	public void user_leaves_fisrtname_field_blank_and_clicks_the_next_button() throws Throwable {
		personalDetails.setFirstName("");
		Thread.sleep(2000);
		personalDetails.setNext();
	}

	@Then("^display appropriate alert message$")
	public void display_appropriate_alert_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: " + alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user leaves lastname field blank and clicks the  next button$")
	public void user_leaves_lastname_field_blank_and_clicks_the_next_button() throws Throwable {
		personalDetails.setFirstName("Swarup");
		Thread.sleep(2000);
		personalDetails.setLastName("");
		Thread.sleep(2000);
		personalDetails.setNext();
	}

	@When("^user leaves email field blank and clicks the  next button$")
	public void user_leaves_email_field_blank_and_clicks_the_next_button() throws Throwable {
		personalDetails.setFirstName("Swarup");
		Thread.sleep(2000);
		personalDetails.setLastName("Talukdar");
		Thread.sleep(2000);
		personalDetails.setEmail("");
		personalDetails.setNext();
	}

	@When("^user enters email field with wrong email format and clicks the  next button$")
	public void user_enters_email_field_with_wrong_email_format_and_clicks_the_next_button() throws Throwable {
		personalDetails.setFirstName("Swarup");
		Thread.sleep(2000);
		personalDetails.setLastName("Talukdar");
		Thread.sleep(2000);
		personalDetails.setEmail("abbhbvhvhu");
		Thread.sleep(2000);
		personalDetails.setNext();
	}

	@When("^user leaves contact number field blank and clicks the  next button$")
	public void user_leaves_contact_number_field_blank_and_clicks_the_next_button() throws Throwable {
		personalDetails.setFirstName("Swarup");
		Thread.sleep(2000);
		personalDetails.setLastName("Talukdar");
		Thread.sleep(2000);
		personalDetails.setEmail("swarup@gmail.com");
		Thread.sleep(2000);
		personalDetails.setContactNumber("");
		Thread.sleep(2000);
		personalDetails.setNext();
	}

	@When("^user fills contact number field with wrong data and clicks the  next button$")
	public void user_fills_contact_number_field_with_wrong_data_and_clicks_the_next_button() throws Throwable {
		personalDetails.setFirstName("Swarup");
		Thread.sleep(2000);
		personalDetails.setLastName("Talukdar");
		Thread.sleep(2000);
		personalDetails.setEmail("swarup@gmail.com");
		Thread.sleep(2000);
		personalDetails.setContactNumber("1254");
		Thread.sleep(2000);
		personalDetails.setNext();
	}

	@When("^user leaves address line1 field blank and clicks the  next button$")
	public void user_leaves_address_line1_field_blank_and_clicks_the_next_button(int arg1) throws Throwable {
		personalDetails.setFirstName("Swarup");
		Thread.sleep(2000);
		personalDetails.setLastName("Talukdar");
		Thread.sleep(2000);
		personalDetails.setEmail("swarup@gmail.com");
		Thread.sleep(2000);
		personalDetails.setContactNumber("9874562130");
		Thread.sleep(2000);
		personalDetails.setAddressLine1("");
		Thread.sleep(2000);
		personalDetails.setNext();
	}

	@When("^user leaves address line2 field blank and clicks the  next button$")
	public void user_leaves_address_line2_field_blank_and_clicks_the_next_button(int arg1) throws Throwable {
		personalDetails.setFirstName("Swarup");
		Thread.sleep(2000);
		personalDetails.setLastName("Talukdar");
		Thread.sleep(2000);
		personalDetails.setEmail("swarup@gmail.com");
		Thread.sleep(2000);
		personalDetails.setContactNumber("9874562130");
		Thread.sleep(2000);
		personalDetails.setAddressLine1("Chennai");
		Thread.sleep(2000);
		personalDetails.setAddressLine2("");
		Thread.sleep(2000);
		personalDetails.setNext();
	}

	@When("^user forgot to select any city and clicks the  next button$")
	public void user_forgot_to_select_any_city_and_clicks_the_next_button() throws Throwable {
		personalDetails.setFirstName("Swarup");
		Thread.sleep(2000);
		personalDetails.setLastName("Talukdar");
		Thread.sleep(2000);
		personalDetails.setEmail("swarup@gmail.com");
		Thread.sleep(2000);
		personalDetails.setContactNumber("9874562130");
		Thread.sleep(2000);
		personalDetails.setAddressLine1("Chennai");
		Thread.sleep(2000);
		personalDetails.setAddressLine2("");
		Thread.sleep(2000);
		personalDetails.setNext();
	}

	@When("^user forgot to select any state and clicks the  next button$")
	public void user_forgot_to_select_any_state_and_clicks_the_next_button() throws Throwable {
		personalDetails.setFirstName("Swarup");
		Thread.sleep(2000);
		personalDetails.setLastName("Talukdar");
		Thread.sleep(2000);
		personalDetails.setEmail("swarup@gmail.com");
		Thread.sleep(2000);
		personalDetails.setContactNumber("9874562130");
		Thread.sleep(2000);
		personalDetails.setAddressLine1("Chennai");
		Thread.sleep(2000);
		personalDetails.setAddressLine2("");
		Thread.sleep(2000);
		personalDetails.setCity(1);
		Thread.sleep(2000);
		personalDetails.setNext();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		Thread.sleep(2000);
		personalDetails.setLastName("Talukdar");
		Thread.sleep(2000);
		personalDetails.setEmail("swarup@gmail.com");
		Thread.sleep(2000);
		personalDetails.setContactNumber("9874562130");
		Thread.sleep(2000);
		personalDetails.setAddressLine1("Chennai");
		Thread.sleep(2000);
		personalDetails.setAddressLine2("");
		Thread.sleep(2000);
		personalDetails.setCity(1);
		Thread.sleep(2000);
		personalDetails.setState(1);
		personalDetails.setNext();
	}

	@Then("^navigate to Educational Details webpage$")
	public void navigate_to_Educational_Details_webpage() throws Throwable {
		driver.navigate().to(
				"file:///D:/Swarup Talukdar/Workspace/STS/selenium/Module3_161710/src/test/java/features/EducationalDetails.html");
		Thread.sleep(2000);
		System.out.println("\n navigated to Educationakl details page");
		driver.close();
	}

}
