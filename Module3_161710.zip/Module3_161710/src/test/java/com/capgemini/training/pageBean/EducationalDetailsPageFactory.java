/*
 * Author: Swarup Talukdar
 * Employee ID: 161710
*/
package com.capgemini.training.pageBean;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class EducationalDetailsPageFactory {
	WebDriver driver;

	public EducationalDetailsPageFactory() {

	}

//Initialization of page elements
	public EducationalDetailsPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(name = "graduation")
	@CacheLookup
	private WebElement graduation;

	@FindBy(how = How.NAME, using = "percentage")
	@CacheLookup
	private WebElement percentage;

	@FindBy(how = How.NAME, using = "passingYear")
	@CacheLookup
	private WebElement passingYear;

	@FindBy(how = How.NAME, using = "projectName")
	@CacheLookup
	private WebElement projectName;

	@FindBy(name = "technologies")
	@CacheLookup
	private List<WebElement> technologiesUsed;

	@FindBy(name = "otherTechnologies")
	@CacheLookup
	private WebElement otherTechnologies;

	@FindBy(xpath = "//*[@id=\"btnRegister\"]")
	@CacheLookup
	private WebElement registerMe;

	public WebElement getGraduation() {
		return graduation;
	}

	public WebElement getPercentage() {
		return percentage;
	}

	public WebElement getPassingYear() {
		return passingYear;
	}

	public WebElement getProjectName() {
		return projectName;
	}

	public List<WebElement> getTechnologiesUsed() {
		return technologiesUsed;
	}

	public WebElement getOtherTechnologies() {
		return otherTechnologies;
	}

	public WebElement getRegisterMe() {
		return registerMe;
	}

	public void setGraduation(int index) {
		Select drop = new Select(graduation);
		drop.selectByIndex(index);
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public void setTechnologiesUsed(List<Integer> tech) {

		Iterator<Integer> it = tech.iterator();
		while (it.hasNext()) {
			int a = it.next();
			if (a == 1) {
				this.technologiesUsed.get(0).click();
			} else if (a == 2) {
				this.technologiesUsed.get(1).click();
			} else if (a == 3) {
				this.technologiesUsed.get(2).click();
			} else if (a == 3) {
				this.technologiesUsed.get(3).click();
			} else {
			}
		}
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}

	public void setRegisterMe() {
		this.registerMe.click();

	}

}
