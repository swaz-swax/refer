/*
 * Author: Swarup Talukdar
 * Employee ID: 161710
*/
package com.capgemini.training.pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PersonalDetailsPageFactory {
	WebDriver driver;

	public PersonalDetailsPageFactory() {

	}

	// Initialization of page elements
	public PersonalDetailsPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(how = How.NAME, using = "txtFN")
	@CacheLookup
	private WebElement firstName;

	@FindBy(how = How.NAME, using = "txtLastName")
	@CacheLookup
	private WebElement lastName;

	@FindBy(xpath = "//*[@id=\"txtEmail\"]")
	@CacheLookup
	private WebElement email;

	@FindBy(xpath = "//*[@id=\"txtPhone\"]")
	@CacheLookup
	private WebElement contactNumber;

	@FindBy(how = How.NAME, using = "address1")
	@CacheLookup
	private WebElement addressLine1;

	@FindBy(how = How.NAME, using = "address2")
	@CacheLookup
	private WebElement addressLine2;

	@FindBy(name = "city")
	@CacheLookup
	private WebElement city;

	@FindBy(name = "state")
	@CacheLookup
	private WebElement state;

	@FindBy(xpath = "/html/body/form/table/tbody/tr[11]/td/a")
	@CacheLookup
	private WebElement next;

	public WebElement getNext() {
		return next;
	}

	public void setNext() {
		this.next.click();
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getContactNumber() {
		return contactNumber;
	}

	public WebElement getAddressLine1() {
		return addressLine1;
	}

	public WebElement getAddressLine2() {
		return addressLine2;
	}

	public WebElement getCity() {
		return city;
	}

	public WebElement getState() {
		return state;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber.sendKeys(contactNumber);
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1.sendKeys(addressLine1);
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2.sendKeys(addressLine2);
	}

	public void setCity(int index) {
		Select drop = new Select(city);
		drop.selectByIndex(index);
	}

	public void setState(int index) {
		Select drop = new Select(state);
		drop.selectByIndex(index);
	}

}
