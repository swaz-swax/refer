/*
 * Author: Swarup Talukdar
 * Employee ID: 161710
*/
package features;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
	plugin = {"pretty","html:html-output"} ,tags= {"@tag"},glue= {"com.capgemini.training.stepdef"}
		)
public class TestRunner {

}
