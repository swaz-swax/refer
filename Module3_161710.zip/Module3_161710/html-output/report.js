$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/fPersonalDetails.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Swarup Talukdar"
    },
    {
      "line": 2,
      "value": "#Employee ID: 161710"
    },
    {
      "line": 3,
      "value": "#Keywords Summary :"
    },
    {
      "line": 4,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 5,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 6,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 7,
      "value": "#When: Some key actions"
    },
    {
      "line": 8,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 9,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 10,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 11,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 12,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 13,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 14,
      "value": "#| (Data Tables)"
    },
    {
      "line": 15,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 16,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 17,
      "value": "#\"\""
    },
    {
      "line": 18,
      "value": "## (Comments)"
    },
    {
      "line": 19,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Personal details application",
  "description": "",
  "id": "personal-details-application",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@tag"
    }
  ]
});
formatter.background({
  "line": 23,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 24,
  "name": "user is on the Personal Details webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonalDetails.user_is_on_the_Personal_Details_webpage()"
});
formatter.result({
  "duration": 3748655421,
  "error_message": "org.openqa.selenium.WebDriverException: unknown error: Runtime.executionContextCreated has invalid \u0027context\u0027: {\"auxData\":{\"frameId\":\"634EFAF316FB26BE13AF607AF6C11F2F\",\"isDefault\":true,\"type\":\"default\"},\"id\":1,\"name\":\"\",\"origin\":\"://\"}\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.9.248315,platform\u003dWindows NT 6.1 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T536\u0027, ip: \u002710.219.35.5\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptSslCerts: true, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {userDataDir: C:\\Users\\swtalukd\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, handlesAlerts: true, javascriptEnabled: true, locationContextEnabled: true, nativeEvents: true, platform: XP, platformName: XP, rotatable: false, takesHeapSnapshot: true, takesScreenshot: true, version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: d25c369af70d8905d81703c971c3eaf2\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.get(RemoteWebDriver.java:276)\r\n\tat com.capgemini.training.stepdef.StepDefPersonalDetails.user_is_on_the_Personal_Details_webpage(StepDefPersonalDetails.java:26)\r\n\tat ✽.Given user is on the Personal Details webpage(features/fPersonalDetails.feature:24)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 26,
  "name": "verify the title",
  "description": "",
  "id": "personal-details-application;verify-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "check the heading of the Personal Details page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonalDetails.check_the_heading_of_the_Personal_Details_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 23,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 24,
  "name": "user is on the Personal Details webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonalDetails.user_is_on_the_Personal_Details_webpage()"
});
formatter.result({
  "duration": 2959332221,
  "error_message": "org.openqa.selenium.WebDriverException: unknown error: Runtime.executionContextCreated has invalid \u0027context\u0027: {\"auxData\":{\"frameId\":\"E68DC4EE0D9ED473396F5BDB3B234F12\",\"isDefault\":true,\"type\":\"default\"},\"id\":1,\"name\":\"\",\"origin\":\"://\"}\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.9.248315,platform\u003dWindows NT 6.1 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T536\u0027, ip: \u002710.219.35.5\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptSslCerts: true, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {userDataDir: C:\\Users\\swtalukd\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, handlesAlerts: true, javascriptEnabled: true, locationContextEnabled: true, nativeEvents: true, platform: XP, platformName: XP, rotatable: false, takesHeapSnapshot: true, takesScreenshot: true, version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: f27fd97aa02fadc9cb6828111cc6410f\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.get(RemoteWebDriver.java:276)\r\n\tat com.capgemini.training.stepdef.StepDefPersonalDetails.user_is_on_the_Personal_Details_webpage(StepDefPersonalDetails.java:26)\r\n\tat ✽.Given user is on the Personal Details webpage(features/fPersonalDetails.feature:24)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 31,
  "name": "unsuccessful with user first name is blank",
  "description": "",
  "id": "personal-details-application;unsuccessful-with-user-first-name-is-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 32,
  "name": "user leaves fisrtname field blank and clicks the  next button",
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "display appropriate alert message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonalDetails.user_leaves_fisrtname_field_blank_and_clicks_the_next_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefPersonalDetails.display_appropriate_alert_message()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 23,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 24,
  "name": "user is on the Personal Details webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonalDetails.user_is_on_the_Personal_Details_webpage()"
});
