package com.capgemini.project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PersonalDetails {
	
	
	WebDriver wd;
	public PersonalDetails(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	@FindBy(name="txtFN")
	@CacheLookup
	WebElement txtFN;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement txtLN;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement Email;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement Phone;
	
	@FindBy(name="address1")
	@CacheLookup
	WebElement address1;
	
	@FindBy(name="address2")
	@CacheLookup
	WebElement address2;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	WebElement city;
	
	
	public Select getSelectOptions(WebElement select) {
		  return new Select(select);
		}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	WebElement state;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[11]/td/a")
	@CacheLookup
	WebElement Next;
	
	
	public WebElement getTxtFN() {
		return txtFN;
	}

	public void setTxtFN(String txtFN) {
		this.txtFN.sendKeys(txtFN);
	}

	public WebElement getTxtLN() {
		return txtLN;
	}

	public void setTxtLN(String txtLN) {
		this.txtLN.sendKeys(txtLN);
	}

	public WebElement getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email.sendKeys(email);
	}

	public WebElement getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone.sendKeys(phone);;
	}

	public WebElement getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);;
	}

	public WebElement getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);;
	}

	/*public WebElement getCity() {
		return city;
	}

	public void setCity(WebElement city) {
		this.city = city;
	}*/
	
	public void setCity(String value) {
		getSelectOptions(city).selectByVisibleText(value);
	}

	public String getCity() {
		return getSelectOptions(city).getFirstSelectedOption().getText();
	}


	/*public WebElement getState() {
		return state;
	}

	public void setState(WebElement state) {
		this.state = state;
	}*/
	
	public void setState(String value) {
		getSelectOptions(state).selectByVisibleText(value);
	}

	public String getState() {
		return getSelectOptions(state).getFirstSelectedOption().getText();
	}

	public WebElement getNext() {
		return Next;
	}

	public void setNext() {
		Next.click();
	}
	
	
	

}
