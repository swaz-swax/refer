package com.capgemini.project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class EducationalDetails {
	
	WebDriver wd;
	public EducationalDetails(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[1]/td[2]/select")
	@CacheLookup
	WebElement graduation;
	
	public Select getSelectOptions(WebElement select) {
		  return new Select(select);
		}
	
	@FindBy(name="percentage")
	@CacheLookup
	WebElement percentage;
	
	@FindBy(name="passingYear")
	@CacheLookup
	WebElement passingYear;
	
	@FindBy(name="projectName")
	@CacheLookup
	WebElement projectName;
	
	@FindBy(xpath="//*[@id=\"cbTechnologies\"]")
	@CacheLookup
	WebElement technologies;
	
	@FindBy(id="txtOtherTechs")
	@CacheLookup
	WebElement txtOtherTechs;
	
	@FindBy(xpath="//*[@id=\"btnRegister\"]")
	@CacheLookup
	WebElement RegisterMe;
	
	
/*	public WebElement getGraduation() {
		return graduation;
	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}*/
	
	public void setGraduation(String value) {
		getSelectOptions(graduation).selectByVisibleText(value);
	}

	public String getGraduation() {
		return getSelectOptions(graduation).getFirstSelectedOption().getText();
	}

	public WebElement getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public WebElement getPassingYear() {
		return passingYear;
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public WebElement getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public WebElement getTechnologies() {
		return technologies;
	}

	public void setTechnologies() {
		this.technologies.click();
	}

	public WebElement gettxtOtherTechs() {
		return txtOtherTechs;
	}

	public void settxtOtherTechs(String txtOtherTechs) {
		this.txtOtherTechs.sendKeys(txtOtherTechs);;
	}

	public WebElement getRegisterMe() {
		return RegisterMe;
	}

	public void setRegisterMe() {
		RegisterMe.click();
	}
	
	
	



}
