package definitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.project.PersonalDetails;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefPersonal {
	
	
	private PersonalDetails fact;
	private WebDriver driver;
	

@Given("^User is on the personal details page$")
public void user_is_on_the_personal_details_page() throws Throwable {
	
	System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
	driver = new ChromeDriver();
	fact=new PersonalDetails(driver);
    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    driver.get("file:///D:/Hema_contents/java_jee/STS/EducationalDetails_161660/PersonalDetails.html");
    
}

@Then("^The title is Verified$")
public void the_title_is_Verified() throws Throwable {
	
	 if(driver.getTitle().contains("Personal Details"))

		 System.out.println("** Title Matched **");
	   else
		   System.out.println("** Title mismatch **");
	 
	  
  
}

@When("^user leaves the first name blank and clicks on the link next$")
public void user_leaves_the_first_name_blank_and_clicks_on_the_link_next() throws Throwable {
	
	fact.setTxtFN("");
	fact.setNext();
    
}

@Then("^print error meassge$")
public void print_error_meassge() throws Throwable {
	
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert :: "+alertMessage);
	Thread.sleep(2000);
	driver.close();
  
}

@When("^user leaves the last name blank and clicks on the	link next$")
public void user_leaves_the_last_name_blank_and_clicks_on_the_link_next() throws Throwable {
	
	fact.setTxtFN("Sneha");
	fact.setTxtLN("");
	fact.setNext();
   
}

@Then("^print error message$")
public void print_error_message() throws Throwable {
	
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert :: "+alertMessage);
	Thread.sleep(2000);
	driver.close();
   
}

@When("^user enters the incorrect email format$")
public void user_enters_the_incorrect_email_format() throws Throwable {
	
	fact.setTxtFN("Sneha");
	fact.setTxtLN("Manga");
	fact.setEmail("sn@.com");
	fact.setNext();
    
}

@When("^user leaves the contact number blank and clicks on the link next$")
public void user_leaves_the_contact_number_blank_and_clicks_on_the_link_next() throws Throwable {
	
	fact.setTxtFN("Sneha");
	fact.setTxtLN("Manga");
	fact.setEmail("sneha@gmail.com");
	fact.setPhone("");
	fact.setNext();
	
   
}

@When("^user enters the wrong number and clicks on the link next$")
public void user_enters_the_wrong_number_and_clicks_on_the_link_next() throws Throwable {
	
	fact.setTxtFN("Sneha");
	fact.setTxtLN("Manga");
	fact.setEmail("sneha@gmail.com");
	fact.setPhone("685674");
	fact.setNext();
    
}

@When("^user leaves the address line (\\d+) blank and clicks on the link next$")
public void user_leaves_the_address_line_blank_and_clicks_on_the_link_next(int arg1) throws Throwable {
	
	fact.setTxtFN("Sneha");
	fact.setTxtLN("Manga");
	fact.setEmail("sneha@gmail.com");
	fact.setPhone("9959473686");
	fact.setAddress1("");
	fact.setNext();
  
}

@When("^user leaves the address line (\\d+) blank and clicks on the next link$")
public void user_leaves_the_address_line_blank_and_clicks_on_the_next_link(int arg1) throws Throwable {
	
	fact.setTxtFN("Sneha");
	fact.setTxtLN("Manga");
	fact.setEmail("sneha@gmail.com");
	fact.setPhone("9959473686");
	fact.setAddress1("Zaheerabad");
	fact.setAddress2("");
	fact.setNext();
   
}

@When("^user leaves the city blank and clicks on the link next$")
public void user_leaves_the_city_blank_and_clicks_on_the_link_next() throws Throwable {
	
	fact.setTxtFN("Sneha");
	fact.setTxtLN("Manga");
	fact.setEmail("sneha@gmail.com");
	fact.setPhone("9959473686");
	fact.setAddress1("Zaheerabad");
	fact.setAddress2("Sangareddy");
	//fact.setCity("");
	fact.setNext();
	
   }

@When("^user leaves the state blank and clicks on the link next$")
public void user_leaves_the_state_blank_and_clicks_on_the_link_next() throws Throwable {
	
	fact.setTxtFN("Sneha");
	fact.setTxtLN("Manga");
	fact.setEmail("sneha@gmail.com");
	fact.setPhone("9959473686");
	fact.setAddress1("Zaheerabad");
	fact.setAddress2("Sangareddy");
	fact.setCity("Hyderabad");
	//fact.setState("");
	fact.setNext();
	
 
}

@When("^user enters all validate details$")
public void user_enters_all_validate_details() throws Throwable {
	
	fact.setTxtFN("Sneha");
	fact.setTxtLN("Manga");
	fact.setEmail("sneha@gmail.com");
	fact.setPhone("9959573686");
	fact.setAddress1("Zaheerabad");
	fact.setAddress2("Sangareddy");
	fact.setCity("Hyderabad");
	fact.setState("Telangana");
	
	fact.setNext();
   
}

@Then("^navigate to next page$")
public void navigate_to_next_page() throws Throwable {
	
	System.out.println("Personal Details are valid and accepted successfully");
	
	driver.navigate().to("file:///D:/Hema_contents/java_jee/STS/EducationalDetails_161660/EducationalDetails.html");
	
	Thread.sleep(3000);
	driver.close();
    
}

}
