package definitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.capgemini.project.EducationalDetails;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepdefEducation {
	

	private EducationalDetails fact;
	private WebDriver driver;
	
	
@Given("^Student is on the Educational Details page$")
public void student_is_on_the_Educational_Details_page() throws Throwable {
    
	System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
	driver = new ChromeDriver();
	fact=new EducationalDetails(driver);
    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    driver.get("file:///D:/Hema_contents/java_jee/STS/EducationalDetails_161660/EducationalDetails.html");
}

@Then("^title is verified$")
public void title_is_verified() throws Throwable {
	
	 if(driver.getTitle().contentEquals("Educational Details"))
		   System.out.println("** Title Matched  **");
	   else
		   System.out.println("** Title mismatch **");
	 
	   driver.close();
   
}

@When("^student leaves the graduation blank and clicks on the Register Me$")
public void student_leaves_the_graduation_blank_and_clicks_on_the_Register_Me() throws Throwable {
	
	//fact.setGraduation("");
	
	fact.setRegisterMe();
    
}

@Then("^the print error message$")
public void the_print_error_message() throws Throwable {
	
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert :: "+alertMessage);
	Thread.sleep(2000);
	driver.close();
  
  
}

@When("^student leaves the percentage blank and clicks on the Register Me$")
public void student_leaves_the_percentage_blank_and_clicks_on_the_Register_Me() throws Throwable {
	
	fact.setGraduation("BTech");
	fact.setPercentage("");
	fact.setRegisterMe();
  
}


@Then("^the  print error message$")
public void the_print_error_message1() throws Throwable {
	
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert :: "+alertMessage);
	Thread.sleep(2000);
	driver.close();
  
   

}
@When("^student leaves the passingyear blank and clicks on the Register Me$")
public void student_leaves_the_passingyear_blank_and_clicks_on_the_Register_Me() throws Throwable {
	
	fact.setGraduation("BTech");
	fact.setPercentage("74.16 %");
	fact.setPassingYear("");
	fact.setRegisterMe();
   
}

@When("^student leaves the project name blank and clicks on the Register Me$")
public void student_leaves_the_project_name_blank_and_clicks_on_the_Register_Me() throws Throwable {
	
	fact.setGraduation("BTech");
	fact.setPercentage("74.16 %");
	fact.setPassingYear("2018");
	fact.setProjectName("");
	fact.setRegisterMe();
   
}

@When("^student does not select the technologies used and clicks on the Register Me$")
public void student_does_not_select_the_technologies_used_and_clicks_on_the_Register_Me() throws Throwable {
	
	fact.setGraduation("BTech");
	fact.setPercentage("74.16 %");
	fact.setPassingYear("2018");
	fact.setProjectName("Health Monitoring System");
	fact.setTechnologies();
	fact.setRegisterMe();
   
}

@When("^student selects the other option and does not select the other technologies and clicks on the Register Me$")
public void student_selects_the_other_option_and_does_not_select_the_other_technologies_and_clicks_on_the_Register_Me() throws Throwable {
   
	fact.setGraduation("BTech");
	fact.setPercentage("74.16 %");
	fact.setPassingYear("2018");
	fact.setProjectName("Health Monitoring System");
	fact.setTechnologies();
	fact.settxtOtherTechs("");
	fact.setRegisterMe();
}

@When("^student enters all valid data$")
public void student_enters_all_valid_data() throws Throwable {
	
	fact.setGraduation("BTech");
	fact.setPercentage("74.16 %");
	fact.setPassingYear("2018");
	fact.setProjectName("Health Monitoring System");
	fact.setTechnologies();
	fact.settxtOtherTechs("Embedded");
	fact.setRegisterMe();
   
}

}
