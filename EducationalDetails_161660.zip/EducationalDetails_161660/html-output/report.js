$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/personal.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Sneha"
    }
  ],
  "line": 2,
  "name": "Entering the details on the Personal Details page",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 6091113340,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Verify the title as Personal Details",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;verify-the-title-as-personal-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "The title is Verified",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonal.the_title_is_Verified()"
});
formatter.result({
  "duration": 7129952,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 5881540474,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Unsuccessfull login with First Name Blank",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;unsuccessfull-login-with-first-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user leaves the first name blank and clicks on the link next",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "print error meassge",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonal.user_leaves_the_first_name_blank_and_clicks_on_the_link_next()"
});
formatter.result({
  "duration": 157534590,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.print_error_meassge()"
});
formatter.result({
  "duration": 6049069139,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 2807571673,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Unsuccessfull login with Last Name Blank",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;unsuccessfull-login-with-last-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user leaves the last name blank and clicks on the\tlink next",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonal.user_leaves_the_last_name_blank_and_clicks_on_the_link_next()"
});
formatter.result({
  "duration": 204245811,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.print_error_message()"
});
formatter.result({
  "duration": 6089842083,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 2814994930,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Unsuccessfull login on entering the\tincorrect email format",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;unsuccessfull-login-on-entering-the-incorrect-email-format",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user enters the incorrect email format",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonal.user_enters_the_incorrect_email_format()"
});
formatter.result({
  "duration": 309024245,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.print_error_message()"
});
formatter.result({
  "duration": 4107802132,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 2955599522,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Unsuccessfull login on with Contact Number Blank",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;unsuccessfull-login-on-with-contact-number-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user leaves the contact number blank and clicks on the link next",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonal.user_leaves_the_contact_number_blank_and_clicks_on_the_link_next()"
});
formatter.result({
  "duration": 362741124,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.print_error_message()"
});
formatter.result({
  "duration": 4129006983,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 3053447778,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Unsuccessfull login on entering the wrong mobile number",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;unsuccessfull-login-on-entering-the-wrong-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "user enters the wrong number and clicks on the link next",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonal.user_enters_the_wrong_number_and_clicks_on_the_link_next()"
});
formatter.result({
  "duration": 414463537,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.print_error_message()"
});
formatter.result({
  "duration": 4295112612,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 3067530471,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Unsuccessfull login with address line 1 blank",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;unsuccessfull-login-with-address-line-1-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 31,
  "name": "user leaves the address line 1 blank and clicks on the link next",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 29
    }
  ],
  "location": "StepDefPersonal.user_leaves_the_address_line_blank_and_clicks_on_the_link_next(int)"
});
formatter.result({
  "duration": 474198275,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.print_error_message()"
});
formatter.result({
  "duration": 6040300786,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 2949627606,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Unsuccessfull login with address line 2 blank",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;unsuccessfull-login-with-address-line-2-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user leaves the address line 2 blank and clicks on the next link",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "2",
      "offset": 29
    }
  ],
  "location": "StepDefPersonal.user_leaves_the_address_line_blank_and_clicks_on_the_next_link(int)"
});
formatter.result({
  "duration": 552952648,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.print_error_message()"
});
formatter.result({
  "duration": 4199941832,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 2805481625,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "Unsuccessfull login with City Blank",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;unsuccessfull-login-with-city-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "user leaves the city blank and clicks on the link next",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonal.user_leaves_the_city_blank_and_clicks_on_the_link_next()"
});
formatter.result({
  "duration": 584341096,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.print_error_message()"
});
formatter.result({
  "duration": 6121307652,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 2721662735,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "Unsuccessfull login with State Blank",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;unsuccessfull-login-with-state-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 43,
  "name": "user leaves the state blank and clicks on the link next",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonal.user_leaves_the_state_blank_and_clicks_on_the_link_next()"
});
formatter.result({
  "duration": 636952855,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.print_error_message()"
});
formatter.result({
  "duration": 6042319866,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "User is on the personal details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefPersonal.user_is_on_the_personal_details_page()"
});
formatter.result({
  "duration": 2869615923,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "Successfull\tlogin",
  "description": "",
  "id": "entering-the-details-on-the-personal-details-page;successfull-login",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 47,
  "name": "user enters all validate details",
  "keyword": "When "
});
formatter.step({
  "line": 48,
  "name": "navigate to next page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefPersonal.user_enters_all_validate_details()"
});
formatter.result({
  "duration": 679798617,
  "status": "passed"
});
formatter.match({
  "location": "StepDefPersonal.navigate_to_next_page()"
});
formatter.result({
  "duration": 37345184,
  "error_message": "org.openqa.selenium.UnhandledAlertException: unexpected alert open: {Alert text : Personal details are validated and accepted successfully.}\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.38.552522 (437e6fbedfa8762dec75e2c5b3ddb86763dc9dcb),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds: null\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T537\u0027, ip: \u002710.219.34.31\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.38.552522 (437e6fbedfa876..., userDataDir: C:\\Users\\snmanga\\AppData\\Lo...}, cssSelectorsEnabled: true, databaseEnabled: false, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: 8a7b97d554101d07bc5daf258e692345\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:172)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.get(RemoteWebDriver.java:276)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteNavigation.to(RemoteWebDriver.java:853)\r\n\tat definitions.StepDefPersonal.navigate_to_next_page(StepDefPersonal.java:196)\r\n\tat ✽.Then navigate to next page(features/personal.feature:48)\r\n",
  "status": "failed"
});
formatter.uri("features/study.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Sneha"
    }
  ],
  "line": 2,
  "name": "Entering the details on the Educational Details Page",
  "description": "",
  "id": "entering-the-details-on-the-educational-details-page",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Student is on the Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepdefEducation.student_is_on_the_Educational_Details_page()"
});
formatter.result({
  "duration": 5470235185,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Verify the title as Educational details",
  "description": "",
  "id": "entering-the-details-on-the-educational-details-page;verify-the-title-as-educational-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "title is verified",
  "keyword": "Then "
});
formatter.match({
  "location": "StepdefEducation.title_is_verified()"
});
formatter.result({
  "duration": 2030722258,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Student is on the Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepdefEducation.student_is_on_the_Educational_Details_page()"
});
formatter.result({
  "duration": 5121283039,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Unsuccessfull register with Graduation Blank",
  "description": "",
  "id": "entering-the-details-on-the-educational-details-page;unsuccessfull-register-with-graduation-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "student leaves the graduation blank and clicks on the Register Me",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "the print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepdefEducation.student_leaves_the_graduation_blank_and_clicks_on_the_Register_Me()"
});
formatter.result({
  "duration": 73565148,
  "status": "passed"
});
formatter.match({
  "location": "StepdefEducation.the_print_error_message()"
});
formatter.result({
  "duration": 4230446675,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Student is on the Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepdefEducation.student_is_on_the_Educational_Details_page()"
});
formatter.result({
  "duration": 3204777450,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Unsuccessfull register with Percentage Blank",
  "description": "",
  "id": "entering-the-details-on-the-educational-details-page;unsuccessfull-register-with-percentage-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "student leaves the percentage blank and clicks on the Register Me",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "the print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepdefEducation.student_leaves_the_percentage_blank_and_clicks_on_the_Register_Me()"
});
formatter.result({
  "duration": 217204103,
  "status": "passed"
});
formatter.match({
  "location": "StepdefEducation.the_print_error_message()"
});
formatter.result({
  "duration": 4250696546,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Student is on the Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepdefEducation.student_is_on_the_Educational_Details_page()"
});
formatter.result({
  "duration": 2747113314,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Unsuccessfull register with PassingYear Blank",
  "description": "",
  "id": "entering-the-details-on-the-educational-details-page;unsuccessfull-register-with-passingyear-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "student leaves the passingyear blank and clicks on the Register Me",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "the print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepdefEducation.student_leaves_the_passingyear_blank_and_clicks_on_the_Register_Me()"
});
formatter.result({
  "duration": 281751899,
  "status": "passed"
});
formatter.match({
  "location": "StepdefEducation.the_print_error_message()"
});
formatter.result({
  "duration": 6047456173,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Student is on the Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepdefEducation.student_is_on_the_Educational_Details_page()"
});
formatter.result({
  "duration": 2972185348,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Unsuccessfull register with Project Name Bank",
  "description": "",
  "id": "entering-the-details-on-the-educational-details-page;unsuccessfull-register-with-project-name-bank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "student leaves the project name blank and clicks on the Register Me",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "the  print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepdefEducation.student_leaves_the_project_name_blank_and_clicks_on_the_Register_Me()"
});
formatter.result({
  "duration": 332349500,
  "status": "passed"
});
formatter.match({
  "location": "StepdefEducation.the_print_error_message1()"
});
formatter.result({
  "duration": 6066510675,
  "error_message": "org.openqa.selenium.WebDriverException: chrome not reachable\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.38.552522 (437e6fbedfa8762dec75e2c5b3ddb86763dc9dcb),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T537\u0027, ip: \u002710.219.34.31\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.38.552522 (437e6fbedfa876..., userDataDir: C:\\Users\\snmanga\\AppData\\Lo...}, cssSelectorsEnabled: true, databaseEnabled: false, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: 3203bbbe28ae0f87f028ed8a506e9ccb\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat definitions.StepdefEducation.the_print_error_message1(StepdefEducation.java:78)\r\n\tat ✽.Then the  print error message(features/study.feature:24)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Student is on the Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepdefEducation.student_is_on_the_Educational_Details_page()"
});
formatter.result({
  "duration": 2933148846,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Unsuccessfull register on not selecting the Technologies Used",
  "description": "",
  "id": "entering-the-details-on-the-educational-details-page;unsuccessfull-register-on-not-selecting-the-technologies-used",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "student does not select the technologies used and clicks on the Register Me",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "the  print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepdefEducation.student_does_not_select_the_technologies_used_and_clicks_on_the_Register_Me()"
});
formatter.result({
  "duration": 529907160,
  "status": "passed"
});
formatter.match({
  "location": "StepdefEducation.the_print_error_message1()"
});
formatter.result({
  "duration": 6077920405,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Student is on the Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepdefEducation.student_is_on_the_Educational_Details_page()"
});
formatter.result({
  "duration": 2800258764,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Unsuccessfull register with other Technologies Blank",
  "description": "",
  "id": "entering-the-details-on-the-educational-details-page;unsuccessfull-register-with-other-technologies-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 31,
  "name": "student selects the other option and does not select the other technologies and clicks on the Register Me",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "the print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepdefEducation.student_selects_the_other_option_and_does_not_select_the_other_technologies_and_clicks_on_the_Register_Me()"
});
formatter.result({
  "duration": 562296943,
  "status": "passed"
});
formatter.match({
  "location": "StepdefEducation.the_print_error_message()"
});
formatter.result({
  "duration": 6083642088,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "Student is on the Educational Details page",
  "keyword": "Given "
});
formatter.match({
  "location": "StepdefEducation.student_is_on_the_Educational_Details_page()"
});
formatter.result({
  "duration": 2830441589,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Successfull register",
  "description": "",
  "id": "entering-the-details-on-the-educational-details-page;successfull-register",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "student enters all valid data",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "the print error message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepdefEducation.student_enters_all_valid_data()"
});
formatter.result({
  "duration": 549150772,
  "status": "passed"
});
formatter.match({
  "location": "StepdefEducation.the_print_error_message()"
});
formatter.result({
  "duration": 4157048895,
  "status": "passed"
});
});