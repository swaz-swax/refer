$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/basicform.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Swarup"
    }
  ],
  "line": 3,
  "name": "Check basic form input",
  "description": "",
  "id": "check-basic-form-input",
  "keyword": "Feature",
  "tags": [
    {
      "line": 2,
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Test name",
  "description": "",
  "id": "check-basic-form-input;test-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "check user name",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "enter empty value in user name text box",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 8,
      "value": "#click to be added"
    }
  ],
  "line": 9,
  "name": "print error message for name field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefBasicForm.check_user_name()"
});
formatter.result({
  "duration": 3541997722,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.enter_empty_value_in_user_name_text_box()"
});
formatter.result({
  "duration": 155075203,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.print_error_message_for_name_field()"
});
formatter.result({
  "duration": 4754457150,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Test city",
  "description": "",
  "id": "check-basic-form-input;test-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 12,
  "name": "check user city",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "enter empty value in city text box",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "print error message for city field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefBasicForm.check_user_city()"
});
formatter.result({
  "duration": 2900674254,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.enter_empty_value_in_city_text_box()"
});
formatter.result({
  "duration": 204217084,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.print_error_message_for_city_field()"
});
formatter.result({
  "duration": 6093184600,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "Test password",
  "description": "",
  "id": "check-basic-form-input;test-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 17,
  "name": "check user password",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "enter empty value in password text box",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "print error message for password field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefBasicForm.check_user_password()"
});
formatter.result({
  "duration": 2903542993,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.enter_empty_value_in_password_text_box()"
});
formatter.result({
  "duration": 277685203,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.print_error_message_for_password_field()"
});
formatter.result({
  "duration": 4112844470,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "Test gender",
  "description": "",
  "id": "check-basic-form-input;test-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 22,
  "name": "check user gender",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "user forgot to select gender",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "print error message for gender field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefBasicForm.check_user_gender()"
});
formatter.result({
  "duration": 2860595999,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.user_forgot_to_select_gender()"
});
formatter.result({
  "duration": 307012146,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.print_error_message_for_gender_field()"
});
formatter.result({
  "duration": 4165933996,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Test language",
  "description": "",
  "id": "check-basic-form-input;test-language",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "check user language",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "user forgot to check language check box",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "print error message for language field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefBasicForm.check_user_language()"
});
formatter.result({
  "duration": 2964406381,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.user_forgot_to_check_language_check_box()"
});
formatter.result({
  "duration": 344300426,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.print_error_message_for_language_field()"
});
formatter.result({
  "duration": 6107275596,
  "status": "passed"
});
formatter.scenario({
  "line": 31,
  "name": "Test My Number",
  "description": "",
  "id": "check-basic-form-input;test-my-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 32,
  "name": "check user MyNumber",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "enter empty value in My number text box",
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "print error message for My number field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefBasicForm.check_user_MyNumber()"
});
formatter.result({
  "duration": 2938358407,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.enter_empty_value_in_My_number_text_box()"
});
formatter.result({
  "duration": 509687996,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.print_error_message_for_My_number_field()"
});
formatter.result({
  "duration": 4272012950,
  "status": "passed"
});
formatter.scenario({
  "line": 36,
  "name": "Test email",
  "description": "",
  "id": "check-basic-form-input;test-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 37,
  "name": "check user email",
  "keyword": "Given "
});
formatter.step({
  "line": 38,
  "name": "enter empty value in email text box",
  "keyword": "When "
});
formatter.step({
  "line": 39,
  "name": "print error message for email field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefBasicForm.check_user_email()"
});
formatter.result({
  "duration": 2800924331,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.enter_empty_value_in_email_text_box()"
});
formatter.result({
  "duration": 499509365,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.print_error_message_for_email_field()"
});
formatter.result({
  "duration": 4202371868,
  "status": "passed"
});
formatter.scenario({
  "line": 41,
  "name": "Test Mobile Number",
  "description": "",
  "id": "check-basic-form-input;test-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 42,
  "name": "check user Mobile Number",
  "keyword": "Given "
});
formatter.step({
  "line": 43,
  "name": "enter empty value in Mobile number text box",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "print error message for Mobile number field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefBasicForm.check_user_Mobile_Number()"
});
formatter.result({
  "duration": 2881804077,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.enter_empty_value_in_Mobile_number_text_box()"
});
formatter.result({
  "duration": 586544615,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.print_error_message_for_Mobile_number_field()"
});
formatter.result({
  "duration": 4238844611,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "Registration successful",
  "description": "",
  "id": "check-basic-form-input;registration-successful",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 47,
  "name": "check user details",
  "keyword": "Given "
});
formatter.step({
  "line": 48,
  "name": "enter all fields",
  "keyword": "When "
});
formatter.step({
  "line": 49,
  "name": "print success message",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefBasicForm.check_user_details()"
});
formatter.result({
  "duration": 2791599799,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.enter_all_fields()"
});
formatter.result({
  "duration": 629796822,
  "status": "passed"
});
formatter.match({
  "location": "StepDefBasicForm.print_success_message()"
});
formatter.result({
  "duration": 4165925791,
  "status": "passed"
});
});