package com.cg.bankwallet.ui;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.bean.Wallet;
import com.cg.bankwallet.exception.WalletNotFound;
import com.cg.bankwallet.service.ServiceImplementation;

public class Presentation {

	public static void main(String[] args) {

		ServiceImplementation service = new ServiceImplementation();
		while (true) {

			System.out.println("Welcome");
			System.out.println("Please Enter Your Choice");
			System.out.println("1--Create Account");
			System.out.println("2--Show Balance");
			System.out.println("3--Deposit");
			System.out.println("4--Withdraw");
			System.out.println("5--Fund Transfer");
			System.out.println("6--Print Transactions");
			System.out.println("7--Exit");

			Wallet wallet = new Wallet();

			Transaction transactions = new Transaction();

			Scanner scanner = new Scanner(System.in);
			int choice = scanner.nextInt();
			switch (choice) {

			case 1:
				System.out.println("Please enter Your First Name");
				String firstName = scanner.next();
				boolean valid_firstName = false;
				try {
					valid_firstName = service.isFirstName(firstName);
				} catch (WalletNotFound e) {

					System.out.println(e.getStatus());
				}
				boolean valid_firstName2 = false;
				String firstName2;
				if (!valid_firstName) {
					do {
						System.out.println("Please Enter a Correct First Name"
								+ "( e.g., 'Manmohan')");
						firstName2 = scanner.next();
						try {
							valid_firstName2 = service.isFirstName(firstName2);
						} catch (WalletNotFound e) {

							System.out.println(e.getStatus());
						}
					} while (!valid_firstName2);
					wallet.setFirstNameOfUser(firstName2);
				} else {
					wallet.setFirstNameOfUser(firstName);
				}

				System.out.println("Please enter Your Last Name");
				String lastName = scanner.next();
				boolean valid_lastName = false;
				try {
					valid_lastName = service.isLastName(lastName);
				} catch (WalletNotFound e) {

					System.out.println(e.getStatus());
				}
				boolean valid_lastName3 = false;
				String lastName3;
				if (!valid_lastName) {
					do {
						System.out.println("Please Enter a Correct Last Name"
								+ "( e.g., 'Joshi')");
						lastName3 = scanner.next();
						try {
							valid_lastName3 = service.isLastName(lastName3);
						} catch (WalletNotFound e) {

							System.out.println(e.getStatus());
						}
					} while (!valid_lastName3);
					wallet.setLastNameOfUser(lastName3);
				} else {
					wallet.setLastNameOfUser(lastName);
				}

				System.out.println("Please enter Your Phone Number");
				String phNum = scanner.next();
				boolean valid_phNum = false;
				try {
					valid_phNum = service.isPhNum(phNum);
				} catch (WalletNotFound e) {
					System.out.println(e.getStatus());
				}
				boolean valid_phNum2 = false;
				String phNum2;
				if (!valid_phNum) {
					do {
						System.out
								.println("Please Enter a Correct Phone Number"
										+ " " + "e.g., '9878451232' ");
						phNum2 = scanner.next();
						try {
							valid_phNum2 = service.isPhNum(phNum2);
						} catch (WalletNotFound e) {
							System.out.println(e.getStatus());
						}
					} while (!valid_phNum2);
					wallet.setPhNumOfUser(phNum2);
				} else {
					wallet.setPhNumOfUser(phNum);
				}

				System.out.println("Please enter Your E-mail Address");
				String email = scanner.next();
				boolean valid_email = false;
				try {
					valid_email = service.isEmail(email);
				} catch (WalletNotFound e) {
					System.out.println(e.getStatus());
				}
				boolean valid_email2 = false;
				String email2;
				if (!valid_email) {
					do {
						System.out.println("Please Enter A Valid Email ID"
								+ " " + "e.g., 'jman@example.com'");
						email2 = scanner.next();
						try {
							valid_email2 = service.isEmail(email2);
						} catch (WalletNotFound e) {
							System.out.println(e.getStatus());
						}
					} while (!valid_email2);
					wallet.setEmailOfUser(email2);
				} else {
					wallet.setEmailOfUser(email);
				}

				System.out.println("Please enter Your Permanent Address");
				String address = scanner.next();
				wallet.setAddressOfUser(address);

				System.out.println("Please enter Your Aadhaar Number");
				String aadhaar = scanner.next();
				boolean valid_aadhaar = false;
				try {
					valid_aadhaar = service.isAadhaar(aadhaar);
				} catch (WalletNotFound e) {
					System.out.println(e.getStatus());
				}
				boolean valid_aadhaar2 = false;
				String aadhaar2;
				if (!valid_aadhaar) {
					do {
						System.out.println("Please Enter Valid Aadhaar Number"
								+ " " + "'123265465888'");
						aadhaar2 = scanner.next();
						try {
							valid_aadhaar2 = service.isAadhaar(aadhaar2);
						} catch (WalletNotFound e) {
							System.out.println(e.getStatus());
						}
					} while (!valid_aadhaar2);
					wallet.setAadhaarOfUser(aadhaar2);
				} else {
					wallet.setAadhaarOfUser(aadhaar);
				}

				Random r1 = new Random();
				Integer accNumOfUser = 1000000 + r1.nextInt(9999);

				wallet.setAccNumOfUser(accNumOfUser);
				// Wallet isAdded = service.createAccount(wallet);

				Random r2 = new Random();
				Integer pin = 1000 + r2.nextInt(9000);

				wallet.setPin(pin);

				System.out.println("Please Enter Initial Balance");
				double balance = scanner.nextDouble();
				wallet.setBalance(balance);
				Wallet isAdded1 = null;
				try {
					isAdded1 = service.createAccount(wallet);
				} catch (WalletNotFound e) {

					System.out.println(e.getStatus());
				}

				System.out.println("ACCOUNT CREATED");
				System.out.println(isAdded1);

				break;
			case 2:
				System.out.println("Enter Your Account Number");
				Integer accNum = scanner.nextInt();

				System.out.println("Please Enter Your Pin");
				Integer pin0 = scanner.nextInt();

				wallet.setAccNumOfUser(accNum);
				wallet.setPin(pin0);
				Wallet isAdded2 = null;
				try {
					isAdded2 = service.showBalance(accNum, pin0);
				} catch (WalletNotFound e) {
					System.out.println(e.getStatus());
				}
				System.out.println("Balance in your Account is" + " "
						+ isAdded2.getBalance());
				break;

			case 3:
				System.out.println("Enter The Amount To Be Deposited");
				Double depositAmount = scanner.nextDouble();
				System.out.println("Enter Account Number");
				Integer accNum1 = scanner.nextInt();

				wallet.setAmount(depositAmount);
				wallet.setAccNumOfUser(accNum1);
				wallet.getBalance();
				try {
					Wallet isAdded3 = service.deposit(depositAmount, accNum1);

				} catch (WalletNotFound e) {
					System.out.println(e.getStatus());
				}

				break;

			case 4:
				System.out.println("Enter The Amount To Be Withdrawn");
				Double withdrawAmount = scanner.nextDouble();

				System.out.println("Enter The Account Number");
				Integer accNum2 = scanner.nextInt();

				System.out.println("Please Enter Your Pin");
				Integer pin1 = scanner.nextInt();

				wallet.setAmount(withdrawAmount);
				wallet.setAccNumOfUser(accNum2);
				try {
					Wallet isAdded4 = service.withdraw(withdrawAmount, accNum2,
							pin1);
				} catch (WalletNotFound e) {
					System.out.println(e.getStatus());
				}

				break;
			case 5:
				System.out.println("Enter Your Account Number");
				Integer accNum3 = scanner.nextInt();

				System.out.println("Enter Beneficiary Account Number");
				Integer accNumBen = scanner.nextInt();

				System.out.println("Please Enter The Amount To Be Transferred");
				Double transferAmount = scanner.nextDouble();

				wallet.setAccNumOfUser(accNum3);
				wallet.setAccNumOfBeneficiary(accNumBen);
				wallet.setAmount(transferAmount);
				try {
					Wallet isAdded5 = service.fundTransfer(transferAmount,
							accNum3, accNumBen);
				} catch (WalletNotFound e) {
					System.out.println(e.getStatus());
				}

				break;
			case 6:
				System.out.println("Please Enter Account Number");
				Integer accNum4 = scanner.nextInt();

				System.out.println("Please enter Your Pin");
				Integer pin2 = scanner.nextInt();

				/*
				 * wallet.setAccNumOfUser(accNum4); wallet.setPin(pin2);
				 */
				try {
					service.transactions(accNum4, pin2);
				} catch (WalletNotFound e) {
					System.out.println(e.getStatus());
				}

				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Please Enter A Correct Choice");
				break;
			}

		}

	}

}
