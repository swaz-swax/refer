package com.cg.bankwallet.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.bean.Wallet;
import com.cg.bankwallet.dao.DaoInterface;
import com.cg.bankwallet.dao.WalletDAOImpl;
import com.cg.bankwallet.exception.WalletNotFound;

public class ServiceImplementation implements ServiceInterface {

	WalletDAOImpl dao = new WalletDAOImpl();

	public boolean isFirstName(String firstName) throws WalletNotFound {

		Pattern Name = Pattern.compile("[A-Z][a-z]+");
		Matcher match = Name.matcher(firstName);
		if (match.matches() == true) {

			return true;
		} else {
			return false;
		}
	}

	public boolean isLastName(String lastName) throws WalletNotFound {

		Pattern Name = Pattern.compile("[A-Z][a-z]+");
		Matcher match = Name.matcher(lastName);
		if (match.matches() == true) {

			return true;
		} else {
			return false;
		}
	}

	public boolean isPhNum(String phNum) throws WalletNotFound {

		Pattern Num = Pattern.compile("[7-9][0-9]{9}");
		Matcher match = Num.matcher(phNum);
		if (match.matches() == true) {

			return true;
		} else {
			return false;
		}
	}

	public boolean isEmail(String email) throws WalletNotFound {

		Pattern Email = Pattern
				.compile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$");
		Matcher match = Email.matcher(email);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isAadhaar(String aadhaar) throws WalletNotFound {

		Pattern Aadhaar = Pattern.compile("[0-9]{12}$");
		Matcher match = Aadhaar.matcher(aadhaar);
		if (match.matches() == true) {

			return true;
		} else {
			return false;
		}
	}

	@Override
	public Wallet createAccount(Wallet wallet) throws WalletNotFound {

		return dao.createAccount(wallet);
	}

	@Override
	public Wallet showBalance(int accNumOfUser, int pin) throws WalletNotFound {

		return dao.showBalance(accNumOfUser, pin);
	}

	@Override
	public Wallet deposit(double amount, int accNum1) throws WalletNotFound {

		return dao.deposit(amount, accNum1);
	}

	@Override
	public Wallet withdraw(double amount, int accNum2, int pin1)
			throws WalletNotFound {

		return dao.withdraw(amount, accNum2, pin1);
	}

	@Override
	public Wallet fundTransfer(double transferAmount, int accNum3, int accNumBen)
			throws WalletNotFound {

		return dao.fundTransfer(transferAmount, accNum3, accNumBen);
	}

	@Override
	public List<Transaction> transactions(int accNum4, int pin2)
			throws WalletNotFound {

		return dao.transactions(accNum4, pin2);
	}

}
