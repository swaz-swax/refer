package com.cg.bankwallet.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Transient;

@Entity
public class Wallet implements Serializable {
	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "customer_accountNumber", length = 30, nullable = false)
	private Integer accNumOfUser = null;
	@Column(name = "customer_first_name", length = 30, nullable = false)
	private String firstNameOfUser;
	@Column(name = "customer_last_name", length = 30, nullable = false)
	private String lastNameOfUser;
	@Column(name = "customer_email", length = 30, nullable = false)
	private String emailOfUser;
	@Column(name = "customer_address", length = 30, nullable = false)
	private String addressOfUser;
	@Column(name = "customer_aadhaar", length = 30, nullable = false)
	private String aadhaarOfUser;
	@Column(name = "customer_number", length = 30, nullable = false)
	private String phNumOfUser;
	@Transient
	private Double amount;
	
	private Integer pin = null;
	@Transient
	private Integer accNumOfBeneficiary;
	@Column(name = "customer_balance", length = 30, nullable = false)
	private double balance;

	@OneToMany(mappedBy = "wallet", cascade = CascadeType.ALL)
	private List<Transaction> transactions = new ArrayList<>();

	public Wallet() {
	}

	public Wallet(String firstNameOfUser, String lastNameOfUser,
			String emailOfUser, String addressOfUser, String aadhaarOfUser,
			String phNumOfUser, Double amount, Integer accNumOfUser,
			Integer pin, double balance, Integer accNumOfBeneficiary) {

		this.firstNameOfUser = firstNameOfUser;
		this.lastNameOfUser = lastNameOfUser;
		this.aadhaarOfUser = aadhaarOfUser;
		this.accNumOfUser = accNumOfUser;
		this.addressOfUser = addressOfUser;
		this.phNumOfUser = phNumOfUser;
		this.amount = amount;
		this.emailOfUser = emailOfUser;
		this.pin = pin;
		this.accNumOfBeneficiary = accNumOfBeneficiary;
		this.balance = balance;
	}

	public String getFirstNameOfUser() {
		return firstNameOfUser;
	}

	public void setFirstNameOfUser(String firstNameOfUser) {
		this.firstNameOfUser = firstNameOfUser;
	}

	public String getLastNameOfUser() {
		return lastNameOfUser;
	}

	public void setLastNameOfUser(String lastNameOfUser) {
		this.lastNameOfUser = lastNameOfUser;
	}

	public String getEmailOfUser() {
		return emailOfUser;
	}

	public void setEmailOfUser(String emailOfUser) {
		this.emailOfUser = emailOfUser;
	}

	public String getAddressOfUser() {
		return addressOfUser;
	}

	public void setAddressOfUser(String addressOfUser) {
		this.addressOfUser = addressOfUser;
	}

	public String getAadhaarOfUser() {
		return aadhaarOfUser;
	}

	public void setAadhaarOfUser(String aadhaarOfUser) {
		this.aadhaarOfUser = aadhaarOfUser;
	}

	public String getPhNumOfUser() {
		return phNumOfUser;
	}

	public Integer getAccNumOfBeneficiary() {
		return accNumOfBeneficiary;
	}

	public void setAccNumOfBeneficiary(Integer accNumOfBeneficiary) {
		this.accNumOfBeneficiary = accNumOfBeneficiary;
	}

	public void setPhNumOfUser(String phNum2) {
		this.phNumOfUser = phNum2;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Integer getAccNumOfUser() {
		return accNumOfUser;
	}

	public void setAccNumOfUser(Integer accNumOfUser) {
		this.accNumOfUser = accNumOfUser;
	}

	public Integer getPin() {
		return pin;
	}

	public void setPin(Integer pin) {
		this.pin = pin;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	public void addTransaction(Transaction transactions) {
		transactions.setWallet(this);// this will avoid nested cascade

		this.getTransactions().add(transactions);
	}

	@Override
	public String toString() {
		return "Wallet [accNumOfUser=" + accNumOfUser + ", firstNameOfUser="
				+ firstNameOfUser + ", lastNameOfUser=" + lastNameOfUser
				+ ", emailOfUser=" + emailOfUser + ", addressOfUser="
				+ addressOfUser + ", aadhaarOfUser=" + aadhaarOfUser
				+ ", phNumOfUser=" + phNumOfUser + ", amount=" + amount
				+ ", pin=" + pin + ", accNumOfBeneficiary="
				+ accNumOfBeneficiary + ", balance=" + balance
				+ ", transactions=" + transactions + "]";
	}

}
