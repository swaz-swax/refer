package com.deloitte.trg.dao;

import java.util.List;

import com.deloitte.trg.entity.CustomerEntity;
import com.deloitte.trg.model.Bank;
import com.deloitte.trg.service.CustomerException;



public interface ICustomerDAO {
	public abstract String addCustomer(Bank bank) throws CustomerException;
	/*public abstract List<CustomerEntity> getAllCustomerDetails() throws CustomerException;
	public abstract CustomerEntity getCustomerById(Integer ID) throws CustomerException;
	public abstract Integer deleteCustomer(Integer ID) throws CustomerException;
	public abstract Integer updateCustomer(CustomerEntity customer) throws CustomerException;*/

	public abstract String getBalance(int id, int pin);

	public abstract String deposit(int id, int accpin, double amount);

	public abstract String withdraw(int id, int accpin, double amount);

	public abstract String transfer(int id1, int accpin1, double amount, int id2);
}
