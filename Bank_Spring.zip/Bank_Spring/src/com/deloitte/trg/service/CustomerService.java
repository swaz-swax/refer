package com.deloitte.trg.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.deloitte.trg.dao.ICustomerDAO;
import com.deloitte.trg.entity.CustomerEntity;
import com.deloitte.trg.model.Bank;
import com.deloitte.trg.model.Customer;

@Service
@Transactional
public class CustomerService implements ICustomerService{
	
	@Autowired
	private ICustomerDAO customerDAO;
	Bank bank1= new Bank();


	@Override
	public String addCustomer(Bank bank) throws CustomerException {
			String status=customerDAO.addCustomer(bank);
			return status;
	}

	@Override
	public String getbalance(int id, int pin) {
		String balance= customerDAO.getBalance(id, pin);
		return balance;
	}

	@Override
	public String deposit(int id, int accpin, double amount) {
		String status="";
		if(amount > 0){
			status=customerDAO.deposit(id,accpin,amount);
		}else{
			status="Invalid amount to deposit";
		}
		return status;
	}

	@Override
	public String withdraw(int id, int accpin, double amount) {
		String status="";
		if(amount > 0){
			 status=customerDAO.withdraw(id,accpin,amount);
		}else{
			status="Invalid amount to withdraw";
		}	
		return	status;
	}

	@Override
	public String transfer(int id1, int accpin1, double amount, int id2) {
		String status="";
		if(amount > 0){
			status=customerDAO.transfer(id1, accpin1, amount, id2);
		}else{
			status="Invalid amount to deposit/withdraw";
		}	
		return	status;
	}
	


	/*private void populateCustomerEntity(Customer customer, CustomerEntity customerEntity) {
		customerEntity.setCustomerId(customer.getCustomerId());
		customerEntity.setCustomerName(customer.getCustomerName());
		customerEntity.setMobile(customer.getMobile());
		customerEntity.setAddress(customer.getAddress());
		customerEntity.setEmail(customer.getEmail());
		customerEntity.setBirthdate(customer.getBirthdate());
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws CustomerException {
		try {
			List<CustomerEntity> customerEntityList=customerDAO.getAllCustomerDetails();
			//System.out.println(customerEntityList.size());
			
			if(customerEntityList !=null) {
				List<Customer> customerList=new ArrayList<>();				
				populateCustomerList(customerList,customerEntityList);
				return customerList;
			}
			throw new CustomerException("Customer List is empty");
		}catch(Exception e) {
			e.printStackTrace();
			throw new CustomerException(e.getMessage());
		}
		
	}

	private void populateCustomerList(List<Customer> customerList, List<CustomerEntity> customerEntityList) {
		Iterator<CustomerEntity> iterator= customerEntityList.iterator();		
		while(iterator.hasNext()) {
			Customer customer=new Customer();
			populateCustomer(customer,iterator.next());
			customerList.add(customer);		
		}
		
	}

	private void populateCustomer(Customer customer, CustomerEntity next) {
		customer.setCustomerId(next.getCustomerId());
		customer.setCustomerName(next.getCustomerName());
		customer.setBirthdate(next.getBirthdate());
		customer.setAddress(next.getAddress());
		customer.setMobile(next.getMobile());
		customer.setEmail(next.getEmail());		
	}

	@Override
	public Customer getCustomerById(Integer ID) throws CustomerException {
		CustomerEntity customerEntity=customerDAO.getCustomerById(ID);
		if(customerEntity!=null) {
			Customer customer=new Customer();
			populateCustomer(customer,customerEntity);
			return customer;
		}
		return null;
	}

	@Override
	public Integer deleteCustomer(Integer ID) throws CustomerException {
		return customerDAO.deleteCustomer(ID);
	}

	@Override
	public Integer updateCustomer(Customer customer) throws CustomerException {
		CustomerEntity customerEntity=new CustomerEntity();
		populateCustomerEntity(customer,customerEntity);
		return customerDAO.updateCustomer(customerEntity);
		}
		*/
	

	

}
