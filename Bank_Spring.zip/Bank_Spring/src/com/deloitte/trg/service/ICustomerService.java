package com.deloitte.trg.service;

import java.util.List;

import com.deloitte.trg.model.Bank;
import com.deloitte.trg.model.Customer;


public interface ICustomerService {
	public abstract String addCustomer(Bank bank) throws CustomerException;
	/*public abstract List<Customer> getAllCustomerDetails() throws CustomerException;
	public abstract Customer getCustomerById(Integer ID) throws CustomerException;
	public abstract Integer deleteCustomer(Integer ID) throws CustomerException;
	public abstract Integer updateCustomer(Customer customer) throws CustomerException;*/

	public abstract String getbalance(int id, int pin);

	public abstract String deposit(int id, int accpin, double amount);

	public abstract String withdraw(int id, int accpin, double amount);

	public abstract String transfer(int id1, int accpin1, double amount, int id2);
}
