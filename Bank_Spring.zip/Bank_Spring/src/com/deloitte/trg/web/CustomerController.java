package com.deloitte.trg.web;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.deloitte.trg.model.Bank;

import com.deloitte.trg.service.CustomerException;
import com.deloitte.trg.service.ICustomerService;



@Controller
@RequestMapping(value="/cust")
public class CustomerController {
	@Autowired
	private ICustomerService customerService;
	
	
	@RequestMapping(value="/cmenu")
	public String getCustomerMenu() {
		return "customer_menu";
	}
	
	@RequestMapping(value="prereg" ,method=RequestMethod.GET)
	public ModelAndView customerForm() {
		Bank b=new Bank();
		return new ModelAndView("cust_reg","bank",b);
	}

	@RequestMapping(value="/register" ,method=RequestMethod.POST)
	public ModelAndView addCustomer( @ModelAttribute(value="bank")Bank bank) {
		System.out.println(bank);
		try {
			String status=customerService.addCustomer(bank);
			return new ModelAndView("cust_status","message",status);
		} catch (CustomerException e) {			
			return new ModelAndView("status","message",e.getMessage());
		}		
	}
	
	/*@RequestMapping(value="/show", method=RequestMethod.GET)
	public ModelAndView getAllCustomerDetails() {
		try {
			List<Customer> customerList=customerService.getAllCustomerDetails();
			if(customerList.size()!=0) {				
				return new ModelAndView("all_customers","customerList",customerList);
			}else {
				return new ModelAndView("cust_status","message","No customers in database");
			}
		}catch(CustomerException e) {
			e.printStackTrace();
			return new ModelAndView("status","message",e.getMessage());
		}
	}*/
	@RequestMapping(value="show" ,method=RequestMethod.GET)
	public ModelAndView getCustomerAccount() {
		Bank b=new Bank();
		return new ModelAndView("show_balance","bank",b);
	}
	
	
	@RequestMapping(value="showb", method=RequestMethod.POST)
	public ModelAndView preUpdateCustomer(@RequestParam(value="accountNo") String account,
										@RequestParam(value="accPin") String pin) throws CustomerException {
		try {
			int id=Integer.parseInt(account);
			int accpin= Integer.parseInt(pin);
			String balance= customerService.getbalance(id,accpin);
			return new ModelAndView("balance_status","message",balance);
			
		}catch(Exception e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	
	@RequestMapping(value="deposit" ,method=RequestMethod.GET)
	public ModelAndView deposit() {
		Bank b=new Bank();
		return new ModelAndView("deposit","bank",b);
	}
	
	
	@RequestMapping(value="depositb", method=RequestMethod.POST)
	public ModelAndView depositAmount(@RequestParam(value="accountNo") String account,
										@RequestParam(value="accPin") String pin,
										@RequestParam(value="amount") String amt) throws CustomerException {
		try {
			int id=Integer.parseInt(account);
			int accpin= Integer.parseInt(pin);
			double amount= Double.parseDouble(amt);
			String balance= customerService.deposit(id,accpin,amount);
			return new ModelAndView("balance_status","message",balance);
			
		}catch(Exception e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	
	@RequestMapping(value="withdraw" ,method=RequestMethod.GET)
	public ModelAndView withdraw() {
		Bank b=new Bank();
		return new ModelAndView("withdraw","bank",b);
	}
	
	
	@RequestMapping(value="withdrawb", method=RequestMethod.POST)
	public ModelAndView withdrawAmount(@RequestParam(value="accountNo") String account,
										@RequestParam(value="accPin") String pin,
										@RequestParam(value="amount") String amt) throws CustomerException {
		try {
			int id=Integer.parseInt(account);
			int accpin= Integer.parseInt(pin);
			double amount= Double.parseDouble(amt);
			String balance= customerService.withdraw(id,accpin,amount);
			return new ModelAndView("balance_status","message",balance);
			
		}catch(Exception e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}

	@RequestMapping(value="fund" ,method=RequestMethod.GET)
	public ModelAndView fundTransfer() {
		Bank b=new Bank();
		return new ModelAndView("fund","bank",b);
	}
	
	
	@RequestMapping(value="fundb", method=RequestMethod.POST)
	public ModelAndView transferFund(@RequestParam(value="accountNo") String account1,
										@RequestParam(value="accPin") String pin1,
										@RequestParam(value="amount") String amt,
										@RequestParam(value="accountNo") String account2) throws CustomerException {
		try {
			int id1=Integer.parseInt(account1);
			int accpin1= Integer.parseInt(pin1);
			double amount= Double.parseDouble(amt);
			int id2=Integer.parseInt(account2);
			String balance= customerService.transfer(id1,accpin1,amount,id2);
			return new ModelAndView("balance_status","message",balance);
			
		}catch(Exception e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	
	@RequestMapping(value="print" ,method=RequestMethod.GET)
	public ModelAndView printTransasction() {
		Bank b=new Bank();
		return new ModelAndView("print_transaction","bank",b);
	}
	
	
	/*@RequestMapping(value="/posteditc", method=RequestMethod.POST)
	public ModelAndView postUpdateCustomer(@ModelAttribute(value="customer") Customer customer) {
		try {
			//System.out.println(customer.getCustomerName());
			int n=customerService.updateCustomer(customer);
			if(n>0) {
				return new ModelAndView("cust_status","message",AppConfig.PROPERTIES.getProperty("CUSTOMER_UPDATE.SUCCESS"));
			}else {
				return new ModelAndView("cust_status","message",AppConfig.PROPERTIES.getProperty("CUSTOMER_UPDATE.FAIL"));
			}
		}catch(CustomerException e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	
	@RequestMapping(value="/deletec", method=RequestMethod.GET)
	public ModelAndView deleteCustomer(@RequestParam(value="customerid") String customerid) {
		try {
			int id=Integer.parseInt(customerid);
			int n= customerService.deleteCustomer(id);
			if(n>0) {
				return new ModelAndView("cust_status","message","Customer Record Deleted");
			}else {
				return new ModelAndView("cust_status","message","Unable to Delete Customer Record");
			}
		}catch(CustomerException e) {
			return new ModelAndView("status","message",e.getMessage());
		}
	}
	*/
	@RequestMapping("/status")
	public String goToCustomerMenu() {
		return "main_menu";
	}
}
